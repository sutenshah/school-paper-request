import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Firestore, collection, doc, setDoc } from '@angular/fire/firestore';

@Component({
  selector: 'app-school-form',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './school-form.html',
  styleUrl: './school-form.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SchoolFormComponent {
  private readonly firestore = inject(Firestore);
  private readonly formBuilder = inject(FormBuilder);
  private readonly docId = doc(collection(this.firestore, 'student_forms')).id;
  protected readonly currentDate = new Date();

  protected readonly form = this.formBuilder.group({
    schoolName: ['', Validators.required],
    address: ['', Validators.required],
    village: ['', Validators.required],
    taluka: ['', Validators.required],
    district: ['', Validators.required],
    pincode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
    deliveryOption: ['', Validators.required],
    parentName: ['', Validators.required],
    examAppName: ['', Validators.required],
    whatsappNumber1: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
    whatsappNumber2: ['', [Validators.pattern('^[0-9]{10}$')]],
    higherClasses: this.formBuilder.group({
      marathi_9: [],
      marathi_10: [],
      english_9: [],
      english_10: [],
      history_9: [],
      history_10: [],
      geography_9: [],
      geography_10: [],
      hindi_9: [],
      hindi_10: [],
      science1_9: [],
      science1_10: [],
      science2_9: [],
      science2_10: [],
      maths1_9: [],
      maths1_10: [],
      maths2_9: [],
      maths2_10: [],
      science1_semi_9: [],
      science1_semi_10: [],
      science2_semi_9: [],
      science2_semi_10: [],
      maths1_semi_9: [],
      maths1_semi_10: [],
      maths2_semi_9: [],
      maths2_semi_10: [],
      hindi_sanskrit_9: [],
      hindi_sanskrit_10: [],
      sanskrit_9: [],
      sanskrit_10: [],
      sanskrit_sanskrit_9: [],
      sanskrit_sanskrit_10: []
    }),
    lowerClasses: this.formBuilder.group({
      marathi_5: [null],
      marathi_6: [null],
      marathi_7: [null],
      marathi_8: [null],
      english_5: [null],
      english_6: [null],
      english_7: [null],
      english_8: [null],
      social_science_5: [{value: '✗', disabled: true}],
      social_science_6: [null],
      social_science_7: [null],
      social_science_8: [null],
      environmental_studies_5: [null],
      environmental_studies_6: [{value: '✗', disabled: true}],
      environmental_studies_7: [{value: '✗', disabled: true}],
      environmental_studies_8: [{value: '✗', disabled: true}],
      hindi_5: [null],
      hindi_6: [null],
      hindi_7: [null],
      hindi_8: [null],
      science_5: [{value: '✗', disabled: true}],
      science_6: [null],
      science_7: [null],
      science_8: [null],
      maths_5: [null],
      maths_6: [null],
      maths_7: [null],
      maths_8: [null],
      science_semi_5: [{value: '✗', disabled: true}],
      science_semi_6: [null],
      science_semi_7: [null],
      science_semi_8: [null],
      maths_semi_5: [null],
      maths_semi_6: [null],
      maths_semi_7: [null],
      maths_semi_8: [null],
      hindi_sanskrit_5: [{value: '✗', disabled: true}],
      hindi_sanskrit_6: [{value: '✗', disabled: true}],
      hindi_sanskrit_7: [{value: '✗', disabled: true}],
      hindi_sanskrit_8: [null],
      sanskrit_sanskrit_marathi_5: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_marathi_6: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_marathi_7: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_marathi_8: [null],
      sanskrit_sanskrit_sanskrit_5: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_sanskrit_6: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_sanskrit_7: [{value: '✗', disabled: true}],
      sanskrit_sanskrit_sanskrit_8: [null]
    })
  });

  constructor() {
    this.form.valueChanges.subscribe(value => {
      this.saveToFirestore(value);
    });
  }

  private async saveToFirestore(data: any) {
    const docRef = doc(this.firestore, 'student_forms', this.docId);
    await setDoc(docRef, data, { merge: true });
  }

  protected onSubmit() {
    if (this.form.valid) {
      console.log(this.form.value);
    }
  }

  protected print() {
    window.print();
  }
}